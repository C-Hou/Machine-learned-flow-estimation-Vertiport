function [windspeedEstimation, Er_windspeedEstimation] = WindConditionEstimator(SensorInputabs, SensorAbs,TestCases, K4windcondition,type)

velocity_list = [0.2 1.3 3.3 5.4 7.9 10.7 13.8 17.1 20.7];
num_wind_speed = size(velocity_list,2);
num_wind_angle = size(SensorAbs,2)/num_wind_speed;
det_wind_angle = 360/num_wind_angle;
index_wind_speed = repmat(1:num_wind_speed,1,num_wind_angle)';
wind_angle_list = 0:det_wind_angle:357;
index_wind_angle = zeros(size(SensorAbs,2),1);
count = 0;
for i = 1:size(SensorAbs,2)
    if mod(i-1,num_wind_speed) == 0
        count = count+1;
    end
    index_wind_angle(i) = wind_angle_list(count);
end
index_angle = index_wind_angle;

index_velocity = zeros(size(index_wind_speed,1),1);

for i = 1:size(index_wind_speed,1)
    index_velocity(i) = velocity_list(index_wind_speed(i));
end

SensorAbsScaled = zeros(size(SensorInputabs,1),size(SensorInputabs,2));
deltaScaledVec = zeros(size(SensorInputabs,1),size(SensorInputabs,2));
deltaScaled = zeros(size(SensorInputabs,2),size(SensorAbs,2));
Lamda = zeros(size(SensorInputabs,2),size(SensorAbs,2));


for i = 1:size(SensorInputabs,2)
    for j = 1:size(SensorAbs,2)
        Lamda(i,j) = velocity_lamda(SensorAbs(:,j),SensorInputabs(:,i));
        SensorAbsScaled(:,j) = SensorAbs(:,j)*abs(Lamda(i,j));
        deltaScaledVec(:,j) = abs((SensorAbsScaled(:,j) - SensorInputabs(:,i)));
        deltaScaled(i,j) = mean(deltaScaledVec(:,j));
    end
end

LamdaScale = zeros(size(SensorInputabs,2),1);
[~,I] = min(deltaScaled,[],2);
for i = 1:size(SensorInputabs,2)
    LamdaScale(i) = Lamda(i,I(i));
end

Ulamda = index_velocity(I);

if type == 'V'
    windspeedEstimation = Ulamda.*LamdaScale;
else
    windspeedEstimation = Ulamda.*sqrt(LamdaScale);
end

Er_windspeedEstimation = (abs(windspeedEstimation-TestCases(:,2)))./TestCases(:,2)*100;

windspeedEstimation = windspeedEstimation';




end