function Xd = velocity_lamda(A,b)

% A = index_angle
% b = gammaSnap

Xd = (inv(A'*A))*A'*b;

% A*(b')* (inv(b*b'));



end