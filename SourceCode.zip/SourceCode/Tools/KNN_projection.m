function Xd = KNN_projection(G,X,Y,K)

% % Description of the input data
% G is the input
% X is the data from the output space
% Y is the data from the input space
% K is the number of neighbours in the decoding algorithm based on KNN

Nsnap = size(X,2);
for i = size(G,2):-1:1
    % Read the i-th point in the manifold to be decoded
    y_trans = G(:,i);
    % Look for its K-nearest neighbours
    for j = Nsnap:-1:1
        norm_yi(j) = norm(Y(:,j)-y_trans);
    end
    [~,ind_neigb] = sort(norm_yi);
    % Store the points in latent and equivalent space of the first K
    % nearest neighbours
    ind_neigb = ind_neigb(1:K);
    neigb_y = Y(:,ind_neigb);
    neigb_x = X(:,ind_neigb);
    
    dist_vec = zeros(1,K);
    for j = 1:K
        dist_vec(j) = dist(y_trans',neigb_y(:,j));
    end
    
    if K == 1
        Xd(:,i) = X(:,ind_neigb(1));
    else
        if size(X,1)==1 && (X(:,ind_neigb(1)) == 0 || (X(:,ind_neigb(1))/2/pi*360 == 360))
            Xd(:,i) = X(:,ind_neigb(1));
        else
            Xd(:,i) = sum(dist_vec.*neigb_x,2)/(sum(dist_vec));
        end
    end
end

end