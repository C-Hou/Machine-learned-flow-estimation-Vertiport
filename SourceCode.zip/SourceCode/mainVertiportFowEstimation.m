%% Load the datasets
clear; close all; clc;

addpath('Tools');

% Load the pre-processed vertiport data: the leading 100 POD modes from 1080 training cases and associated sensor signals
load('.\Data\vertiportPODCo.mat'); % Data format: each column represents one snapshot of POD modes
load('.\Data\sensorDataVabs.mat'); % Data format: each column represents velocity data from one sensor

% Perform k-means clustering on the POD modes
% Note: Due to the random initialization of clusters, results may slightly vary
numClusters = 100;
[idx, centroids, ~] = kmeans(co', numClusters, 'MaxIter', 1000, 'Replicates', 100); 
centroids = centroids'; % Transpose to align centroids, where each column corresponds to a cluster centroid

%% Centroid-based Manifold Learning using ISOMAP
type = 'k';  % Choose between 'epsilon' for epsilon-ISOMAP or 'k' for KNN-ISOMAP

% Compute the distance matrix for the vertiport centroids
DVertiport = squareform(pdist(centroids'));

% Evaluate ISOMAP for different K values
options.display = 0;  % Set to 1 to plot residual variance and 2-D embedding
options.overlay = 0;  % Set to 1 to overlay graph on the 2-D embedding
KValue          = 2:20;
R_K             = zeros(numel(KValue), 1);  % Pre-allocate for residual variance values
for value = KValue
    [~, R] = IsoMap(DVertiport, type, value, options);
    R_K(value - 1) = R(2);  % Store the second residual variance (typically the one of interest)
end

% Run ISOMAP with a chosen K value (e.g., K = 2)
value           = 2;  % Selected value for K
options.display = 0;  % Disable 2-D embedding plot
options.overlay = 0;  % Disable graph overlay

% Perform ISOMAP embedding: Y = low-dimensional embedding, R = residual variance, D_g = geodesic distances
[Y, R, D_g] = IsoMap(DVertiport, type, value, options);

% Extract the low-dimensional coordinates (e.g., 2D embedding)
dim_reduced    = 2;
gammaCentroids = Y.coords{dim_reduced, 1};  % Low-dimensional coordinates of the centroids
Index          = Y.index;  % Index mapping for the reduced space

%% Snapshot-based Manifold Learning using KNN
K4proj = 20;  % Number of nearest neighbors for KNN projection
Snapshot2project = co;  % Original snapshot data for projection
centroidInput = centroids;  % Centroids for KNN projection

% Perform KNN projection to map snapshots onto low-dimensional space
gammaSnap = KNN_projection(Snapshot2project, gammaCentroids, centroidInput, K4proj);

%% Full Manifold without Clustering
DVertiportFull = squareform(pdist(co'));  % Compute the full distance matrix of the POD modes

% Run ISOMAP with a selected K value (e.g., K = 10)
value = 10;  % Chosen K value
options.display = 0;  % Disable plotting residual variance and 2-D embedding
options.overlay = 0;  % Disable overlaying graph on 2-D embedding

% Perform ISOMAP embedding for full manifold: Y_snapshot contains the 2-D embedding
[Y_snapshot, ~] = IsoMap(DVertiportFull, type, value, options);

% Extract the low-dimensional coordinates (e.g., 2D embedding) for the full manifold
gammaSnapFull = Y_snapshot.coords{dim_reduced, 1};  % Low-dimensional coordinates of the snapshots

%% Flow Estimation
% Define the working conditions for the training dataset
numWindSpeed   = 9;
numWindAngle   = size(idx, 1) / numWindSpeed;
detWindAngle   = 360 / numWindAngle;
indexWindSpeed = repmat(1:numWindSpeed, 1, numWindAngle)';
windAngleList  = 0:detWindAngle:357;
indexWindAngle = zeros(size(idx, 1), 1);
count          = 0;

% Assign wind angle based on the index
for i = 1:size(idx, 1)
    if mod(i - 1, numWindSpeed) == 0
        count = count + 1;
    end
    indexWindAngle(i) = windAngleList(count);
end

% Define wind speed list and corresponding indices
uList  = [0.2 1.3 3.3 5.4 7.9 10.7 13.8 17.1 20.7];
indexU = zeros(size(indexWindSpeed, 1), 1);
for i = 1:size(indexWindSpeed, 1)
    indexU(i) = uList(indexWindSpeed(i));
end

% Normalize the sensor data
SensorNond = SensorAbs ./ (indexU');
indexAlpha = indexWindAngle / 360 * 2 * pi;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Testing case 01 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load the working condition for the testing dataset (wind speed = 5)
indexTestCase1 = 1:1080 / 9;
indexTestCase1 = (indexTestCase1 - 1) * 9 + 5;
SensorInputAbs = SensorAbs(:, indexTestCase1);
workingConditionTestCases = [indexAlpha(indexTestCase1), indexU(indexTestCase1)];

% Snapshot manifold with single wind speed from CFD data
K4windCondition = 1;
K4windField     = 20;
SnapTrue        = co(:, indexTestCase1);

% Estimate wind speed
[windSpeedEstimation, ErWindSpeedEstimation] = WindConditionEstimator(SensorInputAbs, SensorAbs, workingConditionTestCases, K4windCondition, 'V');
erWindSpeed1 = mean(abs(ErWindSpeedEstimation), 1);

% Perform KNN projection for latent variables
SensorInputAbsNond  = SensorInputAbs ./ windSpeedEstimation;
SnapEstimationGamma = KNN_projection(SensorInputAbsNond, gammaSnapFull, SensorNond, K4windCondition);

% ISOMAP decoder
gammaSnapInput = gammaSnapFull;
SnapEstimation = isomap_decoder(SnapEstimationGamma, co, gammaSnapInput, K4windField);

% Estimation error
deltaSnapEstimation   = SnapEstimation - SnapTrue;
erEstimation1Separate = vecnorm(deltaSnapEstimation, 2, 1) ./ vecnorm(SnapTrue, 2, 1) * 100;
erEstimation1         = sum(erEstimation1Separate) / size(erEstimation1Separate, 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Testing case 02 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load the working condition for the testing dataset
load('.\Data\TestCasesManifold.mat');
SensorInputAbs = SensorAbs(:, indexTestCase2);
workingConditionTestCases = [indexAlpha(indexTestCase2), indexU(indexTestCase2)];

% Snapshot manifold with multiple wind speeds from CFD data
K4windCondition = 1;
K4windField     = 20;
SnapTrue        = co(:, indexTestCase2);

% Estimate wind speed
[windSpeedEstimation, ErWindSpeedEstimation] = WindConditionEstimator(SensorInputAbs, SensorAbs, workingConditionTestCases, K4windCondition, 'V');
erWindSpeed2 = mean(abs(ErWindSpeedEstimation), 1);

% Perform KNN projection for latent variables
SensorInputAbsNond  = SensorInputAbs ./ windSpeedEstimation;
SnapEstimationGamma = KNN_projection(SensorInputAbsNond, gammaSnapFull, SensorNond, K4windCondition);

% ISOMAP decoder
gammaSnapInput = gammaSnapFull;
SnapEstimation = isomap_decoder(SnapEstimationGamma, co, gammaSnapInput, K4windField);

% Estimation error
deltaSnapEstimation   = SnapEstimation - SnapTrue;
erEstimation2Separate = vecnorm(deltaSnapEstimation, 2, 1) ./ vecnorm(SnapTrue, 2, 1) * 100;
erEstimation2         = sum(erEstimation2Separate) / size(erEstimation2Separate, 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Testing case 03 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load the working condition for the testing dataset
load('.\Data\testCasesManifold.mat');
SensorInputAbs = SensorAbs(:, indexTestCase2);
workingConditionTestCases = [indexAlpha(indexTestCase2), indexU(indexTestCase2)];

% Centroid manifold with multiple wind speeds from CFD data
K4windCondition = 1;
K4windField     = 20;
SnapTrue        = co(:, indexTestCase2);

% Estimate wind speed
[windSpeedEstimation, ErWindSpeedEstimation] = WindConditionEstimator(SensorInputAbs, SensorAbs, workingConditionTestCases, K4windCondition, 'V');
erWindSpeed3 = mean(abs(ErWindSpeedEstimation), 1);

% Perform KNN projection for latent variables
SensorInputAbsNond  = SensorInputAbs ./ windSpeedEstimation;
SnapEstimationGamma = KNN_projection(SensorInputAbsNond, gammaSnap, SensorNond, K4windCondition);

% ISOMAP decoder
gammaSnapInput = gammaSnap;
SnapEstimation = isomap_decoder(SnapEstimationGamma, co, gammaSnapInput, K4windField);

% Estimation error
deltaSnapEstimation   = SnapEstimation - SnapTrue;
erEstimation3Separate = vecnorm(deltaSnapEstimation, 2, 1) ./ vecnorm(SnapTrue, 2, 1) * 100;
erEstimation3         = sum(erEstimation3Separate) / size(erEstimation3Separate, 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Testing case 04 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load the working condition for the testing dataset
load('.\Data\testSensorDataVabs.mat');
SensorInputAbs = SensorInputAbsCase4;
load('.\Data\testCo4.mat');
SnapTrue = co4;
load('.\Data\testCase4.mat');
workingConditionTestCases = testCase4;

% Centroid manifold with multiple wind speeds (out of manifold)
K4windCondition = 2;
K4windField     = 20;

% Estimate wind speed
[windSpeedEstimation, ErWindSpeedEstimation] = WindConditionEstimator(SensorInputAbs, SensorAbs, workingConditionTestCases, K4windCondition, 'V');
erWindSpeed4 = mean(abs(ErWindSpeedEstimation), 1);

% Perform KNN projection for latent variables
SensorInputAbsNond = SensorInputAbs ./ windSpeedEstimation;
SnapEstimationGamma = KNN_projection(SensorInputAbsNond, gammaSnap, SensorNond, K4windCondition);

% ISOMAP decoder
gammaSnapInput = gammaSnap;
SnapEstimation = isomap_decoder(SnapEstimationGamma, co, gammaSnapInput, K4windField);

% Estimation error
deltaSnapEstimation = SnapEstimation - SnapTrue;
erEstimation4Separate = vecnorm(deltaSnapEstimation, 2, 1) ./ vecnorm(SnapTrue, 2, 1) * 100;
erEstimation4 = sum(erEstimation4Separate) / size(erEstimation4Separate, 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Testing case 05 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load the working condition for the testing dataset
load('.\Data\testSensorDataVabs.mat');
load('.\Data\testSensorDataVabsExtra.mat');
SensorInputAbs = [SensorInputAbsCase4(:, 1:172), TestVsensorLarge];
load('.\Data\testCo4.mat');
load('.\Data\testCo5.mat');
SnapTrue = [co4(:, 1:172), co5];
load('.\Data\testCase4.mat');
load('.\Data\testCase5.mat');
workingConditionTestCases = [workingConditionTestCases(1:172, :); TestCaseLarge];

% Centroid manifold with multiple large wind speeds (out of manifold)
K4windCondition = 2;
K4windField     = 20;

% Estimate wind speed
[windSpeedEstimation, ErWindSpeedEstimation] = WindConditionEstimator(SensorInputAbs, SensorAbs, workingConditionTestCases, K4windCondition, 'V');
erWindSpeed5 = mean(abs(ErWindSpeedEstimation), 1);
erWindSpeed5Separate = abs(ErWindSpeedEstimation);

% Perform KNN projection for latent variables
SensorNond = SensorAbs ./ (indexU');
SensorInputAbsNond = SensorInputAbs ./ windSpeedEstimation;
SnapEstimationGamma = KNN_projection(SensorInputAbsNond, gammaSnap, SensorNond, K4windCondition);

% ISOMAP decoder
gammaSnapInput = gammaSnap;
SnapEstimation = isomap_decoder(SnapEstimationGamma, co, gammaSnapInput, K4windField);

% Estimation error
deltaSnapEstimation = SnapEstimation - SnapTrue;
erEstimation5Separate = vecnorm(deltaSnapEstimation, 2, 1) ./ vecnorm(SnapTrue, 2, 1) * 100;
erEstimation5 = sum(erEstimation5Separate) / size(erEstimation5Separate, 2);


%% Random noise
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Testing data 05 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% working condition of the testing data set
load ('.\Data\testSensorDataVabs.mat');
load ('.\Data\testSensorDataVabsExtra.mat');
SensorInputAbs = [SensorInputAbsCase4(:,1:172),TestVsensorLarge];
load ('.\Data\testCo4.mat');
load ('.\Data\testCo5.mat');
SnapTrue = [co4(:,1:172),co5];
load ('.\Data\testCase4.mat');
load ('.\Data\testCase5.mat');
workingConditionTestCases = [workingConditionTestCases(1:172,:);TestCaseLarge];

% Centroid manifold with multi large wind speed out of the manifold 
K4windCondition  = 2;
K4windField      = 20;   

noiseLevel    = [0.1, 5, 10, 15, 20, 25, 30, 35, 40];
dbList        = zeros(1,size(noiseLevel,2));
for i = 1:size(noiseLevel,2)
    dbList(i) = 10*log10(1/(noiseLevel(i)*0.01));
end
erNoisy       = zeros(size(dbList,1),size(dbList,2));

for i = 1:size(dbList,2)
    snr_db = dbList(i);
    SensorInputabs_noisy = awgn(SensorInputAbs, snr_db, 'measured');
    [windSpeedEstimation, ErWindSpeedEstimation] = WindConditionEstimator(SensorInputabs_noisy, SensorAbs, workingConditionTestCases, K4windCondition,'V');
    
    % KNN for latent variables
    SensorNond = SensorAbs./(indexU');
    SensorInputAbsNond = SensorInputabs_noisy./windSpeedEstimation;
    SnapEstimationGamma  = KNN_projection(SensorInputAbsNond,gammaSnap,SensorNond,K4windCondition);
    
    % ISOMAP decoder
    gammaSnapInput = gammaSnap;
    SnapEstimation = isomap_decoder(SnapEstimationGamma,co,gammaSnapInput,K4windField);
    
    deltaSnapEstimation = SnapEstimation - SnapTrue;
    erEstimation5Separate = vecnorm(deltaSnapEstimation,2,1)./vecnorm(SnapTrue,2,1).*100;
    erEstimationNoisy = sum(erEstimation5Separate)/size(erEstimation5Separate,2);
    
    erNoisy(i) = erEstimationNoisy;
end


%% Visulizations
%----------------------- Residual variance -----------------------
figure;
hold on
plot(1:10, R(1:10), 'ko');
plot(1:10, R(1:10), 'k-');

ylabel('\it{R}');
xlabel('Dimensionality');

set(gca,'FontSize',10,'FontName','Times New Roman')
set(gca, 'looseinset', [0,0,0,0])
set(gcf,'units', 'centimeter', 'position',[10,15,6.5,5.5])
%-------------------------------------------------------------


%----------------------- Manifolds -----------------------
% (a)Centroids-based (b)Snapshots-based
figure

[ha, pos] = tight_subplot(1,2,[.05 .15],[.1 .05],[.1 .05]);

axes(ha(1));
scatter(gammaCentroids(1,:),gammaCentroids(2,:),10,...
    'o','MarkerFaceAlpha',0,'MarkerEdgeAlpha',1,'MarkerFaceColor','k','MarkerEdgeColor','k','linewidth',1);

axis equal
set(gca,'FontSize',10)
xlim([-1600 1600])
ylim([-1600 1600])
xticks([-1000 0 1000])
yticks([-1000 0 1000])

xlabel('$\gamma_1$','Interpreter','latex','FontSize',10,'FontName','Times New Roman')
ylabel('$\gamma_2$','Interpreter','latex','FontSize',10,'FontName','Times New Roman')
set(gca,'FontSize',10,'FontName','Times New Roman')
title('(a)')


axes(ha(2));
scatter(gammaSnap(1,:),gammaSnap(2,:),10,'filled',...
    'o','MarkerFaceAlpha',1,'MarkerEdgeAlpha',1,'MarkerFaceColor','k','MarkerEdgeColor','k');
axis equal
set(gca,'FontSize',10)
xlim([-1600 1600])
ylim([-1600 1600])
xticks([-1000 0 1000])
yticks([-1000 0 1000])

xlabel('$\gamma_1$','Interpreter','latex','FontSize',10,'FontName','Times New Roman')
ylabel('$\gamma_2$','Interpreter','latex','FontSize',10,'FontName','Times New Roman')
set(gca,'FontSize',10,'FontName','Times New Roman')
title('(b)')

set(gcf,'units', 'centimeter', 'position',[10,15,15,7])
%-------------------------------------------------------------



%----------------------- Gamma and wind speed -----------------------
figure
colormap_plot = nclCM(238);

for i = 1:size(gammaSnap,2)
    scatter(gammaSnap(1,i),gammaSnap(2,i),10,'filled',...
        'o','MarkerFaceAlpha',1,'MarkerEdgeAlpha',.4,'LineWidth', 1.5,...
        'MarkerEdgeColor',colormap_plot(ceil(indexWindSpeed(i)/9*(size(colormap_plot,1)-1)+1),:),'MarkerFaceColor',colormap_plot(ceil(indexWindSpeed(i)/9*(size(colormap_plot,1)-1)+1),:));
    hold on
end

axis equal
set(gca,'FontSize',10)
xlim([-1200 1200])
ylim([-1200 1200])
xticks([-1000 0 1000])
yticks([-1000 0 1000])

xlabel('$\gamma_1$','Interpreter','latex','FontSize',10,'FontName','Times New Roman')
ylabel('$\gamma_2$','Interpreter','latex','FontSize',10,'FontName','Times New Roman')

colormap(colormap_plot)
h = colorbar('Ticks',[0 0.49 1],...
         'TickLabels',{0,10,21});
     
h.Label.String = '\it{U}_{\infty }';
set(gca,'FontSize',10,'FontName','Times New Roman')
set(gca, 'looseinset', [0,0,0,0.1])
set(gcf,'units', 'centimeter', 'position',[10,15,7.5,5.5])
%-------------------------------------------------------------


%----------------------- Gamma and wind angle -----------------------
figure
colormap_plot = nclCM(367);
index_wind_angle_plot = indexWindAngle;

for i = 1:size(indexWindAngle,1)
    if i < 1080 - 1080/4 +1 
        index_wind_angle_plot(i) = indexWindAngle(i+1080/4); 
    else
        index_wind_angle_plot(i) = indexWindAngle(i-(1080-1080/4));
    end
end

for i = 1:size(gammaSnap,2)
    scatter(gammaSnap(1,i),gammaSnap(2,i),10,'filled',...
        'o','MarkerFaceAlpha',1,'MarkerEdgeAlpha',.4,'LineWidth', 1.5,...
        'MarkerEdgeColor',colormap_plot(ceil(index_wind_angle_plot(i)/360*(size(colormap_plot,1)-1)+1),:),'MarkerFaceColor',colormap_plot(ceil(index_wind_angle_plot(i)/360*(size(colormap_plot,1)-1)+1),:));
    hold on
end

axis equal
set(gca,'FontSize',10)
xlim([-1200 1200])
ylim([-1200 1200])
xticks([-1000 0 1000])
yticks([-1000 0 1000])

xlabel('$\gamma_1$','Interpreter','latex','FontSize',10,'FontName','Times New Roman')
ylabel('$\gamma_2$','Interpreter','latex','FontSize',10,'FontName','Times New Roman')

colormap(colormap_plot)
h = colorbar('Ticks',[0 0.25 0.5 0.75 1],...
         'TickLabels',{0,90,180,270,360});
     
h.Label.String = '\alpha';
set(gca,'FontSize',10,'FontName','Times New Roman')
set(gca, 'looseinset', [0,0,0,0.1])
set(gcf,'units', 'centimeter', 'position',[10,15,7.5,5.5])
%-------------------------------------------------------------

% %----------------------- Estimation error with noisy data -----------------------
% figure
% plot(noiseLevel, erNoisy, 'ko-');
% grid on
% xlim([0 40])
% ylim([0 50])
% ylabel('E $\%$','Interpreter','latex','FontSize',10,'FontName','Times New Roman')
% xlabel('Noise level $\%$','Interpreter','latex','FontSize',10,'FontName','Times New Roman');
% set(gca,'FontSize',10,'FontName','Times New Roman')
% set(gca, 'looseinset', [0,0,0,0])
% set(gcf,'units', 'centimeter', 'position',[10,15,6.5,5])
% %-------------------------------------------------------------



% %----------------------- Choice of K -----------------------
% figure
% plot(KValue,R_K,'-o','MarkerSize',3)
% hold on
% plot(KValue(1),R_K(1),'r.','MarkerSize',30)
% hold on
% x1 = [2, 2]; 
% y1 = [0, 0.1]; 
% plot(x1, y1, '-k'); 
% hold on
% x1 = [5, 5]; 
% y1 = [0, 0.1]; 
% plot(x1, y1, '-k'); 
% 
% xlabel('$k$','Interpreter','latex','FontSize',15)
% ylabel('Residual variance','Interpreter','latex','FontSize',15)
% title('Residual variance-$k$','Interpreter','latex','FontSize',15)
% xlim([0 20])
% ylim([0 0.1])
% set(gcf,'units', 'centimeter', 'position',[10,15,6.5,5])
% %-------------------------------------------------------------
